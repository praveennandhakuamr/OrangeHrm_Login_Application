import { test } from "@playwright/test";
import { ExcelReader } from "../utils/excelReader";
import { LoginPage } from "../pages/LoginPage";

test.describe("OrangeHRM - Excel-driven specific cell login", () => {
  test("login using row 7, col 1 and col 2", async ({ page }) => {
    const file = "test-data/loginData.xlsx";
    const sheet = "Sheet1";

    const rowToUse = 7;
    const usernameCol = 1;
    const passwordCol = 2;

    const username = ExcelReader.getCell(file, sheet, rowToUse, usernameCol);
    const password = ExcelReader.getCell(file, sheet, rowToUse, passwordCol);

    const login = new LoginPage(page);
    await login.navigate();
    await login.login(String(username ?? ""), String(password ?? ""));

    try {
      await login.expectSuccess();
      await login.logoutIfLoggedIn();
      console.log("Login successful for:", username);
    } catch {
      await login.expectFailure();
      console.log("Login failed as expected for:", username);
    }
  });
});
