import { Page, expect } from "@playwright/test";

export class LoginPage {
  readonly page: Page;
  readonly username = "input[name='username']";
  readonly password = "input[name='password']";
  readonly submitBtn = "button[type='submit']";
  readonly errorMessage = ".oxd-alert-content-text";
  readonly dashboardHeader = "h6";

  constructor(page: Page) {
    this.page = page;
  }

  async navigate() {
    await this.page.goto("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
  }

  async login(username: string, password: string) {
    await this.page.fill(this.username, username ?? "");
    await this.page.fill(this.password, password ?? "");
    await this.page.click(this.submitBtn);
  }

  async expectSuccess() {
    await expect(this.page.locator(this.dashboardHeader)).toContainText("Dashboard");
  }

  async expectFailure() {
    await expect(this.page.locator(this.errorMessage)).toBeVisible();
  }

  async logoutIfLoggedIn() {
    const avatar = this.page.locator(".oxd-userdropdown-tab");
    if (await avatar.count() > 0) {
      await avatar.click();
      const logout = this.page.locator("a:has-text('Logout')");
      if (await logout.count() > 0) await logout.click();
    }
  }
}
