import * as XLSX from "xlsx";

export class ExcelReader {
  static getCell(filePath: string, sheetName: string, row: number, col: number): any {
    const workbook = XLSX.readFile(filePath);
    const sheet = workbook.Sheets[sheetName ?? workbook.SheetNames[0]];
    const data: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1 });
    if (!data || !data[row - 1]) return undefined;
    return data[row - 1][col - 1];
  }

  static getRow(filePath: string, sheetName: string, row: number): any[] | undefined {
    const workbook = XLSX.readFile(filePath);
    const sheet = workbook.Sheets[sheetName ?? workbook.SheetNames[0]];
    const data: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1 });
    return data[row - 1];
  }

  static getAll(filePath: string, sheetName: string): any[][] {
    const workbook = XLSX.readFile(filePath);
    const sheet = workbook.Sheets[sheetName ?? workbook.SheetNames[0]];
    return XLSX.utils.sheet_to_json(sheet, { header: 1 }) as any[][];
  }
}
